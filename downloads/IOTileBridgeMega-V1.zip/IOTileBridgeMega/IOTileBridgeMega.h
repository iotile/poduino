#ifndef __IOTILEBRIDGEMEGA_H__
#define __IOTILEBRIDGEMEGA_H__

#include "Arduino.h"

typedef void (*IOTileBridgeCallback)(unsigned int event);

class IOTileBridge
{
	private:
	unsigned int	 	 pin;
	unsigned int		 initialized;

	public:
	IOTileBridge(unsigned int pin, IOTileBridgeCallback new_callback);

	void begin();
	void sendEvent(uint8_t stream, uint32_t value);

	void checkReceivedEvents();
};

#endif