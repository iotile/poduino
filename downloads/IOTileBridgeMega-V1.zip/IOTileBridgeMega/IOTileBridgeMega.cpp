#include "IOTileBridgeMega.h"

static IOTileBridgeCallback globalCallback = NULL;

IOTileBridge::IOTileBridge(unsigned int new_pin, IOTileBridgeCallback new_callback): pin(new_pin), initialized(false)
{
	pinMode(this->pin, OUTPUT);
	digitalWrite(this->pin, HIGH);

	globalCallback = new_callback;

	//Enable a pullup on UART RX to level shift the OD output from the tile
	pinMode(15, INPUT_PULLUP);
}

void IOTileBridge::begin()
{
	Serial3.begin(9600);
	while(!Serial3)
		;

	initialized = true;
}

void IOTileBridge::sendEvent(uint8_t stream, uint32_t value)
{
	uint8_t byte0 = (value >>  0) & 0xFF;
	uint8_t byte1 = (value >>  8) & 0xFF;
	uint8_t byte2 = (value >> 16) & 0xFF;
	uint8_t byte3 = (value >> 24) & 0xFF;

	if (!this->initialized)
		return;

	digitalWrite(this->pin, LOW);
	delay(1);
	Serial3.write(byte0);
	Serial3.write(byte1);
	Serial3.write(byte2);
	Serial3.write(byte3);
	Serial3.write(stream);
	Serial3.flush();
	delay(1);
	digitalWrite(this->pin, HIGH);
}

void IOTileBridge::checkReceivedEvents()
{
	while(Serial3.available())
	{
		int value = Serial3.read();
		globalCallback(value);
	}
}
